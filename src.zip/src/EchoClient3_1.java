import java.net.*;
import java.util.ArrayList;
import java.io.*; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EchoClient3_1 extends JFrame implements ActionListener
{  
  //public EchoServer3 server;
  public EchoServer3_1 server;
  // GUI items
  JButton sendButton;
  JButton connectButton;
  JTextField machineInfo;
  JTextField portInfo;
  JTextField message;
  JTextArea history;
  private String name;

  // Network Items
  boolean connected;
  Socket echoSocket;
  PrintWriter out;
  BufferedReader in;

   // set up GUI
   public EchoClient3_1() 
   {
      super("Echo Client");

      // get content pane and set its layout
      Container container = getContentPane();
      container.setLayout(new BorderLayout());
      
      // set up the North panel
      JPanel upperPanel = new JPanel();
      upperPanel.setLayout(new GridLayout (4,2));
      container.add(upperPanel, BorderLayout.NORTH);
      
      // create buttons
      connected = false;

      upperPanel.add (new JLabel("Message: ", JLabel.RIGHT));
      message = new JTextField ("");
      message.addActionListener(this);
      upperPanel.add(message);
      
      sendButton = new JButton("Send Message");
      sendButton.addActionListener(this);
      sendButton.setEnabled(false);
      upperPanel.add(sendButton);

      connectButton = new JButton("Connect to Server");
      connectButton.addActionListener(this);
      upperPanel.add(connectButton);
                      
      String machineAddress = null;
      try {
		InetAddress addr = InetAddress.getLocalHost();
		machineAddress = addr.getHostAddress();
      } 
      catch (UnknownHostException e) {
		e.printStackTrace();
      }
      
      upperPanel.add(new JLabel("Server Address: ", JLabel.RIGHT));
      machineInfo = new JTextField (machineAddress);
      upperPanel.add(machineInfo);
                      
      upperPanel.add(new JLabel("Server Port: ", JLabel.RIGHT));
      portInfo = new JTextField("");
      upperPanel.add(portInfo);
                      
      history = new JTextArea(10, 40);
      history.setEditable(false);
      container.add(new JScrollPane(history), BorderLayout.CENTER);

      setSize(500, 250);
      setVisible(true);
      
      //name = (String)JOptionPane.showInputDialog(null, "Please enter your name", null, JOptionPane.INFORMATION_MESSAGE, null, null, null);
      //clientList.add(name);
      //minimum capacity of clients
      //clientList.ensureCapacity(100);
      //System.out.println(name);
      
      //server.getClientList().add(name);
      //server.setClientList(clientList);
//      int x = 0;
//      while(clientList != null){
//    	  repaint();
//    	  System.out.println(clientList.get(x));
//    	  x++;
//      }

   } // end Client constructor
    
   public static void main(String args[])
   { 
      EchoClient3_1 application = new EchoClient3_1();
      application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
   }

    // handle button event
    public void actionPerformed(ActionEvent event)
    {
       Object[] options = {"All", "One"};
       if (connected && (event.getSource() == sendButton || event.getSource() == message))
       {
    	 int n = JOptionPane.showOptionDialog(null, "Would you like to send a message to all clients or a specific client?", null, JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
         if (n == JOptionPane.YES_OPTION){		//all clients
        	 doSendMessage();
         }
         else {									//specific client
        	 String s = (String)JOptionPane.showInputDialog(null, "Enter name of client", null, JOptionPane.INFORMATION_MESSAGE, null, null, null);
        	 //clientList.size();
        	// ArrayList<String> clientList = server.getClientList();
        	 System.out.println("Name of chosen client is: " + s);
        	 System.out.println("Server.clientList.size(): " + server.clientList.size());
        	 for (int i = 0; i < server.clientList.size(); i++){
        	 //for (String str : clientList){
        		 String str = server.clientList.get(i);
        		 if (s.compareTo(str) == 0){					//search the list for the name typed in
//        			 doSendMessage();
//        			 JOptionPane.showMessageDialog(null, "Message sent", null, JOptionPane.INFORMATION_MESSAGE);
        		 }
        		 else {
        			 continue;
        			//JOptionPane.showMessageDialog(null, "Client is not active. Try again", null, JOptionPane.ERROR_MESSAGE); 
        		 
        		 }
        	 }
        	 JOptionPane.showMessageDialog(null, "Client is not active. Try again", null, JOptionPane.ERROR_MESSAGE); //not in list
        	 
         }
       }
       else if (event.getSource() == connectButton)
       {
         doManageConnection();
       }
    }
    
    public String getName(){
 	   name = (String)JOptionPane.showInputDialog(null, "Please enter your name", null, JOptionPane.INFORMATION_MESSAGE, null, null, null);
 	   System.out.println(name);
 	   return name;
 	   //server.getClientList().add(name);
    }

    public void doSendMessage()
    {
      try
      {
        out.println(message.getText());
        history.insert (this.name + ": " + in.readLine() + "\n" , 0);
      }
      catch (IOException e) 
      {
        history.insert ("Error in processing message ", 0);
      }
    }
    
    public void doManageConnection()
    {
      if (connected == false)
      {
        String machineName = null;
        int portNum = -1;
        try {
        	//portNum = sock.getLocalPort();
            machineName = machineInfo.getText();
            portNum = Integer.parseInt(portInfo.getText());
            echoSocket = new Socket(machineName, portNum);
            out = new PrintWriter(echoSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
            sendButton.setEnabled(true);
            connected = true;
            connectButton.setText("Disconnect from Server");
            
            //while (true){
            	String line = in.readLine();
            	if (line.startsWith("Username")){
            		out.println(getName());
            	}
            	else {
            		out.print("error");
            	}
            //}
            
        } catch (NumberFormatException e) {
            history.insert("Server Port must be an integer\n", 0);
        } catch (UnknownHostException e) {
            history.insert("Don't know about host: " + machineName, 0);
        } catch (IOException e) {
            history.insert("Couldn't get I/O for " + "the connection to: " + machineName, 0);
        }

      }
      else
      {
        try 
        {
          out.close();
          in.close();
          echoSocket.close();
          sendButton.setEnabled(false);
          connected = false;
          connectButton.setText("Connect to Server");
        }
        catch (IOException e) 
        {
            history.insert ("Error in closing down Socket ", 0);
        }
      }        
    }
 } // end class EchoServer3