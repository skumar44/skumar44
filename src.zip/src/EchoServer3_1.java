/*Shruthi Kumar - skumar44, Geraldine Torres - gtorres23
 * CS 342 Project 4 
 */
import java.net.*;
import java.util.ArrayList;
import java.util.concurrent.LinkedBlockingQueue;
import java.io.*; 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class EchoServer3_1 extends JFrame implements ActionListener{
  
  //public static ArrayList<String> clientList = new ArrayList<String>();
  public ArrayList<String> clientList = new ArrayList<String>();
  //private LinkedBlockingQueue<Object> messages = new LinkedBlockingQueue<Object>();
  //public EchoClient3 client;
  // GUI items
  JButton ssButton;
  JButton connect;
  JLabel machineInfo;
  JLabel portInfo;
  JTextArea history;
  private boolean running;
  public int index = 0;

  // Network Items
  boolean serverContinue;
  ServerSocket serverSocket;

   // set up GUI
   public EchoServer3_1()
   {
      super("Echo Server");

      // get content pane and set its layout
      Container container = getContentPane();
      container.setLayout(new FlowLayout());

      // create buttons
      running = false;
      ssButton = new JButton("Start Listening");
      ssButton.addActionListener(this);
      container.add(ssButton);
      
      String machineAddress = null;
      try
      {  
        InetAddress addr = InetAddress.getLocalHost();
        machineAddress = addr.getHostAddress();
      }
      catch (UnknownHostException e)
      {
  		e.printStackTrace();
      }
      machineInfo = new JLabel (machineAddress);
      container.add(machineInfo);
      portInfo = new JLabel (" Not Listening ");
      container.add(portInfo);

      history = new JTextArea (10, 40);
      history.setEditable(false);
      container.add(new JScrollPane(history));

      setSize(500, 250);
      setVisible(true);
      
   } // end server constructor
   
   
   public ArrayList<String> getClientList() {
    	  return clientList;
    }
   
   public static void main(String args[])
   { 
      EchoServer3_1 application = new EchoServer3_1();
      application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      
      ConnectionThread connect = new ConnectionThread(application);
      
   }

    // handle button event
    public void actionPerformed(ActionEvent event)
    {
       if (running == false)
       {
         new ConnectionThread (this);
       }
       else
       {
         serverContinue = false;
         ssButton.setText("Start Listening");
         portInfo.setText(" Not Listening ");
       }
    }
 
 } // end class EchoServer3


class ConnectionThread extends Thread
 {
   EchoServer3_1 gui;
   
   public ConnectionThread(EchoServer3_1 es3)
   {
     gui = es3;
     start();
   }
   
   public void run()
   {
     gui.serverContinue = true;
     
     try 
     { 
       gui.serverSocket = new ServerSocket(0); 
       gui.portInfo.setText("Listening on Port: " + gui.serverSocket.getLocalPort());
       System.out.println("Connection Socket Created");
       try { 
         while (gui.serverContinue)
         {
           System.out.println ("Waiting for Connection");
           
           gui.ssButton.setText("Stop Listening");
           new CommunicationThread (gui.serverSocket.accept(), gui); 
         }
       } 
       catch (IOException e)  
       { 
         System.err.println("Accept failed."); 
         System.exit(1); 
       } 
     } 
     catch (IOException e) 
     { 
       System.err.println("Could not listen on port: 10008."); 
       System.exit(1); 
     } 
     finally
     {
       try {
         gui.serverSocket.close(); 
       }
       catch (IOException e)
       { 
         System.err.println("Could not close port: 10008."); 
         System.exit(1); 
       } 
     }
   }
 }

class CommunicationThread extends Thread
{ 
 //private boolean serverContinue = true;
 private Socket clientSocket;
 private EchoServer3_1 gui;
 public EchoClient3_1 client;
 private String name;
 //int size = 0;
 
 //public ArrayList<String> clientList;
 public LinkedBlockingQueue<Object> messages = new LinkedBlockingQueue<Object>();


 public CommunicationThread(Socket clientSoc, EchoServer3_1 ec3)
   {
    clientSocket = clientSoc;
    gui = ec3;
    start();
   }

 public void run()
   {
    System.out.println("New Communication Thread Started");
   
    try { 
         PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true); 
         BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 

         //gui.clientList = new ArrayList<String>();
         String inputLine; 
         String name;
         //int size = 0;
         
         while (true){
        	 out.println("Username");
        	 name = in.readLine();
        	 if (name == null){
        		 return;
        	 }
        	 try {
        		 synchronized(gui.clientList){
        			 if (!gui.clientList.contains(name)){
        				 //int size = 0;
        				 gui.clientList.add(gui.index, name);
        				 System.out.println(gui.index);
        				 System.out.println(name);
        				 gui.index++;
        				 gui.history.insert("Active client: " + name + "\n", 0);
        				 System.out.println(gui.index);
        				 System.out.println(name);
        				 //gui.clientList.size()
        				 for (String str : gui.clientList){
        					 System.out.println(str);
        				 }
        				 System.out.println(gui.clientList);
        				 break;
        			 }
        		 }
        	 }
        	 catch (Exception e){
        		 System.out.println(e);
        	 }
         }
  
        //find client that you need to send the message to. 
         	
         //print on server
         while ((inputLine = in.readLine()) != null) //while the message isn't null
             { 
              System.out.println(name + ": " + inputLine); 
              gui.history.insert(name + ": " + inputLine, 0);
              out.println(inputLine); 
              if (inputLine.equals("Bye.")|| (in.readLine() == null)) {
            	  for(int i=0; i<gui.clientList.size(); i++) {
            		  if(name == gui.clientList.get(i)) {
            			  gui.clientList.remove(gui.clientList.get(i)); //if correct name, then remove from list
            			  break;
            		  }
            		  
            	  }
            	  //gui.clientList.remove(gui.index);
              	System.out.println(gui.clientList);
                 
             }
             if(in.readLine() == null){
            	  for(int i=0; i<gui.clientList.size(); i++) {
            		  if(name == gui.clientList.get(i)) {
            			  gui.clientList.remove(gui.clientList.get(i)); //if correct name, then remove from list
            			  break;
            		  }
            		  
            	  }
            	  //gui.clientList.remove(gui.index);
              	System.out.println(gui.clientList);
             }
              if (inputLine.equals("End Server.")) 
                  gui.serverContinue = false; 
             } 

         out.close(); 
         in.close();  //closes the stream, client is disconnected
         for(int j = 0; j<gui.clientList.size(); j++){
        	 if(name == gui.clientList.get(j)) {
        		 gui.clientList.remove(gui.clientList.get(j));
        	 }
         }
         System.out.println(gui.clientList);
         clientSocket.close(); 
        } 
    catch (IOException e) 
        { 
         System.err.println("Problem with Communication Server");
         //System.exit(1); 
        } 
    }


} 
