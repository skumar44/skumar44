/*We hardcoded the message in the rsamessage.txt file.  
 * If you want to replace it with another message, it too must be saved as rsamessage.txt 
 * 
 */

/* The name of the text file with the 20 prime numbers is called primeNumbers.src and located in the same 
 * directory as the rest of the files relevant to this assignment.
 * 
 * The block file is called blocked_2.txt
 * The unblocked file is called unblocked_2.txt
 * 
 */
