/* 
 * Anthony Leon  and Shruthi Kumar

 * NetIds: aleon9 and skumar44
*  CS 342 - Project 3
*  RSA Encryption/Decryption
*  UIC Spring 2016
*/

package Homework3;

/*
 * Class: HugeIntClass
 * Description: Creates a new HugeIntClass type which is bigger than int and can perform the following operations: Addition, Subtraction, Multiplication, Division, Modulus, Relations
 */
public class HugeIntClass {

	private int size;
	private int arr[];
	
	/*
	 * Constructor with an int as a parameter
	 * Description: store the int into type HugeIntClass 
	 */
	public HugeIntClass(int num){
			
		int count = 0; 
		int numberTocount = num;  
	
		while(num > 0) // perform till the least significant digit 
		{
			count++; // increment the counter 
			num = num / 10; // check by stripping it's least significant number 
		}
		
		size = count; 
		arr = new int[size]; // allocate new array
		
		for(int j = 0; j < size; j++){ 
			arr[j] = numberTocount % 10; // store each number into the numbers array 
			numberTocount = numberTocount / 10; // move to the next number
		}	
	}
	
	/*
	 * Constructor with a String as a parameter
	 * Description: store the String in type HugeIntClass
	 */
	public HugeIntClass(String s){
		size = s.length(); 
		arr = new int[size]; // allocate size 

		for(int i = 0; i < size; i++){ 
			int get_num = s.charAt(size-1-i) - '0'; 
			arr[i] = get_num; 
		}		  
	}
	
	/*
	 * Constructor with an Array of ints as a parameter
	 * Description: stores the array into type HugeIntClass
	 */
	public HugeIntClass(int [] num){
		int count = 0; 
		size = num.length; 
		
		for(int i = 0; i < num.length; i++){
			// check if any number in array is 0
			if( num[i]== 0) 
				count++; // if it is then increment 
		}
		//check if all the numbers in the array are 0 so compare to size
		if(count == size){ 
			size = 1; 
			arr = new int[1];
			arr[0] = 0; 
		}
		else
		{
			while(num[size-1] == 0) 
				size--; 
			 
			arr = new int[size]; // allocate the memory for the array 
			for(int y =0; y < size; y++){ 
				arr[y] = num[y]; // copy the rest of the digits as it is 
			} 
		}
	}
	
	/*
	public HugeIntClass(HugeIntClass num){
		size=num.size;
		arr=new int[size];
		for(int i=0; i<size-1; i++){
			this.arr[i]=num.arr[i];
		}
	}
	 */
	
	/*
	 * Method: Addition()
	 * Description: takes a HugeIntClass type as parameter and perform the addition operation
	 */
	public HugeIntClass Addition(HugeIntClass num){
		
		int max = 0;
		
		if(num.size > this.size) max=num.size +1;
		else
			max=this.size + 1;
		
		int[] result = new int[max];
		
		int carry = 0; 

		for(int i = 0; i <max-1; i++){
			int temp = 0;
			if( i < size){
				temp += arr[i];
			}
			
			if( i < num.size){
				temp += num.arr[i];
			}
			
			temp += carry;
			result[i] = temp % 10;
			carry = temp / 10;
		}
		
		//last carry
		if(carry == 1) result[max - 1] = 1;
		else
			result[max - 1] = 0;
	
		return new HugeIntClass(result);
	}
	
	/*
	 * Method: Subtraction()
	 * Description: takes a HugeIntClass type as parameter and perform the subtraction operation
	 */
	public HugeIntClass Subtraction(HugeIntClass num) { 
	    if(num.isGreater(this)) return new HugeIntClass(-1); 
		
		int [] result = new int[size];

	    int carry=0;
	     int i = 0; 
	     while(i < size ){
	      int temp = arr[i];
	      if (i < num.size)
	        temp -= num.arr[i];
	      
	      temp -= carry;
	      carry = 0; 

	      if (temp < 0) {
	        temp = temp + 10;
	        carry = 1;
	      }
	      
	      result[i] = temp;
	      i++;
	    }
	     return new HugeIntClass(result);
	}
	
	/*
	 * Method: Multiplication()
	 * Description: takes a HugeIntClass type as parameter and perform the multiplication operation
	 */
	public HugeIntClass Multiplication( HugeIntClass num ) {
		int[] result = new int[this.size+num.size];
		    
		for(int i = 0; i<num.size; i++){
			int carry=0;
			for(int j=0; j<this.size; j++){
				result[j + i] += carry + this.arr[j] * num.arr[i];
				carry = result[j+i] / 10;
				result[j+i] = result[j+i] % 10;
			}
			result[i+this.size ] +=carry;
		}
		return new HugeIntClass(result);
	}
	

	
	/*
	 * Same concept as Relations but instead return boolean, isGreater(), isEqual(), isGreaterthanEqual()
	 */
	public boolean isGreater(HugeIntClass num){
		if( size > num.size){
			return true;
		}
		else if(size < num.size){
			return false;
		}
		else{
			for( int i = size-1; i >= 0; i--){
				if(arr[i] < num.arr[i]){
					return false;
				}
				else if( arr[i]  > num.arr[i]){
					return true;
				}
			}
			return false;
		}
		}
	
	public boolean isEqual( HugeIntClass num){
		if( size != num.size ){
			return false;
		}
		else{
			for( int i = size-1; i >= 0; i--){ //for( int i = size; i >= 0; i--){
				if( arr[i] != num.arr[i]){
					return false;
				}
			}
			return true;
		}
	}
	
	public boolean isGreaterthanEqual(HugeIntClass num){
		return this.isGreater(num) || this.isEqual(num);
	}
	
	/*
	 * Method: Division()
	 * Description: takes a HugeIntClass type as parameter and perform the division operation with the use of subtraction
	 */
	HugeIntClass remainder = null;
	
	public HugeIntClass Division(HugeIntClass divisor) {
	   HugeIntClass count = new HugeIntClass(0);
	   HugeIntClass dividend = this;
	   while(dividend.isGreaterthanEqual(divisor) || dividend.isEqual(divisor)) { //while 100 >= 25, subtract 25
	     dividend = dividend.Subtraction(divisor); // dividend = 100 - 25
	     count = count.Addition(new HugeIntClass(1)); //count++
	   }
	   if(!dividend.isGreaterthanEqual(divisor)) {
	     remainder = dividend;
	   }
	   return count; //count is the quotient
	 }//end of Division method
	
	/*
	 * Method Modulus()
	 * Description: calls the Division operation and returns the remainder
	 */
	public HugeIntClass Modulus(HugeIntClass num){
		   this.Division(num);
		   return remainder;
	}
	/*
	 * Method: Relation()
	 * Description: comparing two HugeIntClass types and returns an int depending on whether one is greater than, less than or equal to the other
	 */
	public int Relation(HugeIntClass num1){ 
		//check size, if one is bigger or one is smaller
		if(this.size < num1.size) return -1;
		else if(this.size > num1.size) return 1;
		else{
			//now same size, have to check each individual one
			for(int i=size-1; i>=0; i--){
				if(this.arr[i] > num1.arr[i]) return 1;
				else if(this.arr[i] < num1.arr[i]) return -1;	
			}
			//get here then the same number
			return 0;
		}
	}
	
	/*
	 * Method: Exponent()
	 * Description: calculates the power of a base with the use of the multiplication operation
	 */
	public HugeIntClass Exponent(HugeIntClass exp) {
		   HugeIntClass num = this;
		   HugeIntClass one = new HugeIntClass(1);

		   HugeIntClass product = this;
		   
		   while((exp.Relation(one)) > 0) { 
		     product = product.Multiplication(num); 
		     //System.out.println("" + product);
		     
		     exp = exp.Subtraction(one);
		     //System.out.println("" + exp);
		   }
		   return product;  //final answer
		 }//end of Exponent
	
	/*
	 * Method: powMod()
	 * Description: use to create public and private key
	 */
	 public HugeIntClass powMod(HugeIntClass other, HugeIntClass base) {
		  
		  HugeIntClass base1 =  base.Multiplication(new HugeIntClass(10));
		  HugeIntClass result = new HugeIntClass(0);
		  HugeIntClass num = this;
		  HugeIntClass one = new HugeIntClass(1);
		  
		  HugeIntClass product = this; 
		  HugeIntClass zero = new HugeIntClass(0);
		  HugeIntClass n1 = new HugeIntClass(1);
		  HugeIntClass result1 = new HugeIntClass(0);
		  while(other.isGreater(n1)){
		   product = product.Multiplication(num).Modulus(base1);
		   other = other.Subtraction(one); //.mod(base); // .mod(base);
		  }
		  result1 = product;
		  return result1; 
		 }//end of powMod 
	
	/*
	 * Method: gcd()
	 * Description: Takes two HugeIntClass types and calculates the greatest common denominator
	 */
	public static HugeIntClass gcd(HugeIntClass p, HugeIntClass q) {
		if(q.Relation(q) == 0){ 
			return p;
		}
		
		HugeIntClass temp=p;
		//System.out.println("" + temp);
		temp =temp.Modulus(q);
		//System.out.println("" + temp);
		return gcd(q, temp);
	    }//end of gcd
	
	/*
	 * toString()
	 * Description: will return numbers in correct order
	 */
	public String toString() {
	    String ans = "";
	    
	    int length = size;
	
	    if(length > 1){
	    	while(arr[length-1]==0 && length > 1)length--;
	    }
	    while (length !=0){
	    	ans += arr[length-1];
	    	length--;
	    }
	    return ans;
	  }
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//HugeIntClass test = new HugeIntClass("25685094049");
		//HugeIntClass test1 = new HugeIntClass("349004904904904");
		
		//HugeIntClass test = new HugeIntClass("100");
		//HugeIntClass test1 = new HugeIntClass("25");
		
		HugeIntClass t1 = new HugeIntClass("2");
		HugeIntClass t2 = new HugeIntClass("2");
		HugeIntClass t3 = new HugeIntClass("10");
		
		//HugeIntClass test = new HugeIntClass("32416187666");
		//HugeIntClass test1 = new HugeIntClass("32416187526");
		
		HugeIntClass test1 = new HugeIntClass("122944837");
		HugeIntClass test = new HugeIntClass("122945227");
		
		System.out.println(test);
		System.out.println(test1);
		
	
		HugeIntClass add = test.Addition(test1);
		//System.out.println("" + test.arr[0]);
		System.out.println(test + " + " + test1 + " = " + add);
		//System.out.println("");
		//tests for all operations 
		HugeIntClass sub = test.Subtraction(test1);
		System.out.println(test + " - " + test1 + " = " + sub);
		//System.out.println("");
		
		int rela = test.Relation(test1);
		System.out.println(test + " is " + test1 + " = " + rela);
		//System.out.println("");
	
		HugeIntClass mul = test.Multiplication(test1);

		System.out.println(test + " * " + test1 + " = " + mul);
		//System.out.println("");
		

		HugeIntClass div = test.Division(test1);
		System.out.println(test + " / " + test1 + " = " + div);
		//System.out.println("");
		
		HugeIntClass mod1 = test.Modulus(test1);
		System.out.println(test + " mod" + test1 + " = " + mod1);
		System.out.println("");
		
		// might take long
		HugeIntClass exp= test.Exponent(test1);
		System.out.println(test + " exponent" + test1 + " = " + exp);
		System.out.println("");
		
		//HugeIntClass pmod = test.modExponent(base, pow, mod);
		//System.out.println(base + " powmod" + pow + " = " + pmod);
		//System.out.println("");
		
		t1.powMod(t2, t3);
		System.out.println("" + t1);
		
		// works but might take long
		//HugeIntClass gcd1 = gcd(test, test1);
		//System.out.println(test + " gcd" + test1 + " = " + gcd1);
		//System.out.println("");
		
		//System.out.println(test + " * " + test1 + " = " + mul);
		//System.out.println("");
	}

}
