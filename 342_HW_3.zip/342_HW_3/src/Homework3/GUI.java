 /* Anthony Leon  and Shruthi Kumar

 * NetIds: aleon9 and skumar44
*  CS 342 - Project 3
*  RSA Encryption/Decryption
*  UIC Spring 2016
*/

package Homework3;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GUI extends HugeIntClass{
	private JFrame frame = new JFrame("RSA Encryption/Decryption");
	private JButton k_create;
	private JButton block;
	private JButton unblock;
	private JButton enc_dec;
	
	private boolean odd_l;
	
	
	private File inputfile;
	private FileReader reader;
	private BufferedReader buff;
	private FileWriter f;
	
	public GUI(){
		super("");
		frame.setLayout(new BorderLayout());;
		
		k_create = new JButton("Key Creation");
		block = new JButton("Block");
		unblock = new JButton("Unblock");
		enc_dec = new JButton("encrypt/decrypt");
		
		
		JPanel boardPane = new JPanel( new GridLayout(2, 2, 2, 2) );
		frame.add(boardPane, BorderLayout.CENTER); 
		
		k_create.setPreferredSize(new Dimension(25, 50));
		k_create.addActionListener(new createkey());
		boardPane.add(k_create);
		
		block.setPreferredSize(new Dimension(25, 50));
		block.addActionListener(new blocking());
		boardPane.add(block);
		
		unblock.setPreferredSize(new Dimension(25, 50));
		unblock.addActionListener(new unblocking());
		boardPane.add(unblock);
		
		enc_dec.setPreferredSize(new Dimension(25, 50));
		//enc_dec.addActionListener(new encryption());
		boardPane.add(enc_dec);
		
		frame.setSize(300, 300);
		frame.setVisible(true);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}
	
	/*
	 * Method: keyCreate()
	 * Description: calls the HugeIntClass to create n, phi, d, e
	 */
	public static void keyCreate(HugeIntClass x, HugeIntClass y){
		HugeIntClass n = x;
		n = n.Multiplication(y);
		
		System.out.println(n);
		
		HugeIntClass one = new HugeIntClass(1);
		x = x.Subtraction(one);
		y = y.Subtraction(one);
		
		HugeIntClass phi = x;
		phi = phi.Multiplication(y);
		
		System.out.println(phi);
		
		HugeIntClass e = new HugeIntClass(2);
		int counter = 0;
		
		HugeIntClass tmp;
		
		while(e.Relation(n) == -1){
			tmp = gcd(e, phi);
			System.out.println(tmp); //
			if(tmp.Relation(one) == 0){
				counter++;
			e = e.Addition(one);
		}
		
		if(e.Relation(n) != -1){
			System.out.println("Something went wrong");
			return;
		}
		
		System.out.println(e);
		
		HugeIntClass d;
		HugeIntClass modtmp;
		HugeIntClass i = new HugeIntClass(1);
		
		while(true){
			modtmp = phi;
			modtmp=modtmp.Multiplication(i);
			modtmp=modtmp.Addition(one);
			modtmp=modtmp.Modulus(e);
			if(modtmp.Relation(modtmp) == 0){
				counter++;
				d=phi;
				d=d.Multiplication(i);
				d=d.Addition(one);
				d=d.Division(e);
				break;
			}
			i=i.Addition(one);
		}
		
		System.out.println("" + d);
		System.out.println("" + e);
		//call createprivateKey
		
		//call createPublicKey
		
	}
	}
	
	/*
	 * When pressed KeyCreation, creates the key
	 */
	private class createkey implements ActionListener{
		public void actionPerformed(ActionEvent e){
			
			//tried hardcoding to test our CreateKey
			HugeIntClass x = new HugeIntClass("122944837");
			HugeIntClass y = new HugeIntClass("122945227");
			keyCreate(x, y);

		}
	}

	/*
	 * Creates unblocked file with blocking size of 2
	 */
	public void createUnBlockedFile(File rsa_text){
		String s;
		
		int first, second;
		String first_str, second_str;
		
		try{
			//need to read and output a file
			inputfile = new File("unblocked_2.txt");
			inputfile.createNewFile();
			reader = new FileReader(rsa_text);
			buff = new BufferedReader(reader);
			f = new FileWriter(inputfile);
			
			double line_num = (rsa_text.length()/5.0); //found online
			
			//if odd number length
			if((line_num % 1) > 0.0)
				odd_l= true;
			
			//get the char from ASCII value
			for(int i=0; i<(int)line_num; i++){
				s=buff.readLine();
				
				first_str = s.substring(0, 2);
				second_str = s.substring(2, s.length());
				
				first=Integer.parseInt(first_str);
				second=Integer.parseInt(second_str);
				
				if(first == 0) first = 0;
				else if(first == 1) first = 11;
				else if(first == 2) first = 9;
				else if(first == 3) first = 10;
				else if(first == 4) first = 13;
				else{
					first = first + 27;
				}
				
				if(second == 0) second = 0;
				else if(second == 1) second = 11;
				else if(second == 2) second = 9;
				else if(second == 3) second = 10;
				else if(second == 4) second = 13;
				else{
					second = second + 27;
				}
			
				f.write(second);
				f.write(first);
			}
			
			//for odd number of chars
			if(odd_l){
				s = buff.readLine();
				
				second_str = s.substring(0, s.length());
				
				second = Integer.parseInt(second_str);
				
				if(second == 0) second = 0;
				else if(second == 1) second = 11;
				else if(second == 2) second = 9;
				else if(second == 3) second = 10;
				else if(second == 4) second = 13;
				else{
					second = second + 27;
				}
				
				f.write(second);
			}
		
			buff.close();
			reader.close();
			f.close();
			
		}catch(IOException e1){
			e1.printStackTrace();
		}
		
	}

	//creates block file of size 2 blocking
	public void createBlockedFile(File rsa_text){
		
		//going to hard code block by 2
		char[] blocked = new char[2];
		
		int first;
		int second;
		
		String first_str;
		String second_str;
		
		try{
			//need to read and output a file
			inputfile = new File("blocked_2.txt");
			inputfile.createNewFile();
			reader = new FileReader(rsa_text);
			buff = new BufferedReader(reader);
			f = new FileWriter(inputfile);
			
			//length of block 2 loops
			double loop=(double)((rsa_text.length()-1)/2.0d);
			
			//if length is odd
			if(((rsa_text.length()-1) % 2) > 0.0d){
				odd_l=true;
			}
			
			//get the ASCII value with Troy's ASCII conversion and special cases
			for(int i=0; i<(int)loop; i++){
				buff.read(blocked, 0, 2);
				
				if((int)blocked[1] == 0) first = 0;
				else if ((int)blocked[1] == 11) first = 1;
				else if ((int)blocked[1] == 9) first = 2;
				else if ((int)blocked[1] == 10) first = 3;
				else if ((int)blocked[1] == 13) first = 4;
				else {
					first = (int)(blocked[1] - 27);
				}
				
				if((int)blocked[0] == 0) second = 0;
				else if ((int)blocked[0] == 11) second = 1;
				else if ((int)blocked[0] == 9) second = 2;
				else if ((int)blocked[0] == 10) second = 3;
				else if ((int)blocked[0] == 13) second = 4;
				else {
					second = (int)(blocked[0] - 27);
				}
				
				//add the leading zero for some special cases, else represent ASCII value
				if(first < 10){
					first_str = "0" + Integer.toString(first);
				}
				else{
					first_str = Integer.toString(first);
				}
				
				if(second < 10){
					second_str = "0" + Integer.toString(second);
				}
				else{
					second_str = Integer.toString(second);
				}
				
				f.write(first_str + second_str + "\n");
				
			}
			
			//if length is odd add the last ASCII value
			if(odd_l){
				buff.read(blocked, 0, 1);
				second = (int)(blocked[0] - 27);
				if(second < 10){
					second_str = "0" + Integer.toString(second);
				}
				else{
					second_str = Integer.toString(second);
				}
				
				f.write(second_str);
			
			}
			
			buff.close();
			reader.close();
			f.close();
			
		}catch(IOException e1){
			e1.printStackTrace();
		}
		
	}
	
	// when Block button pressed creates blocked file
	private class blocking implements ActionListener{
		public void actionPerformed(ActionEvent e){
			
			File rsa_text = new File("rsamessage.txt");
			createBlockedFile(rsa_text);
		}//end of actionPerformed
	}//end of blocking method with ActionListener
	
	
	// when Unblock button press creates unblock file
	private class unblocking implements ActionListener{
		public void actionPerformed(ActionEvent e){
			File blocked_text = new File("blocked_2.txt");
			createUnBlockedFile(blocked_text);
		}// end of actionPerformed
	}//end of unblocking method with ActionListener
	
	
	/*
	private class encryption implements ActionListener{
		public void actionPerformed(ActionEvent e){
			
		}//end of actionPerformed	
	}// end of encryption method with ActionListener
	*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GUI();   
	}
}
